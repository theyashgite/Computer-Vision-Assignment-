# CCA 3 – Computer Vision Project

**MIT World Peace University | MCA | Computer Vision (Units 3, 4 and 5)**

This repository contains the Jupyter Notebook, student-provided input photographs, YOLO11n model weights, selected output figures, and the technical report for the CCA 3 Computer Vision practical assignment.

## Project structure

```text
CCA3_Computer_Vision_GitHub/
├── My_Computer_Vision_Project.ipynb
├── yolo11n.pt
├── input/
│   ├── myphoto (2).jpeg
│   ├── myphoto2.jpeg
│   ├── myphoto3.jpg
│   └── my_recorded_video.mp4   # Add your own 15–30 second video here
├── outputs/
│   └── selected notebook and detection/motion output images
├── docs/
│   └── CCA3_Computer_Vision_Report.docx
├── README.md
├── requirements.txt
└── .gitignore
```

## Tasks implemented

1. **Image restoration and segmentation:** Gaussian noise, salt-and-pepper noise, Gaussian and median filtering, PSNR, SSIM, thresholding, morphology, Canny edge detection and watershed segmentation.
2. **Feature extraction and matching:** HOG, SIFT keypoints/descriptors, feature matching and matching after 30-degree rotation.
3. **Object recognition:** Haar Cascade (Viola–Jones) face detection and YOLO11n object detection.
4. **Video motion estimation:** frame extraction, frame differencing, MOG2 background subtraction and Lucas–Kanade optical flow.

## Requirements

- Python 3.10 or later (the notebook was developed in an Anaconda/Jupyter environment)
- Jupyter Notebook
- Packages listed in `requirements.txt`

Install dependencies:

```bash
pip install -r requirements.txt
```

## How to run

1. Download or clone this repository.
2. Open a terminal in the repository folder.
3. Install dependencies using the command above.
4. Open the notebook:

   ```bash
   jupyter notebook
   ```

5. Run `My_Computer_Vision_Project.ipynb` from top to bottom.

The notebook expects the three photograph filenames exactly as shown in the `input/` folder. The YOLO weights file `yolo11n.pt` must remain in the repository root.

## Important: Task 4 video requirement

The notebook currently refers to a development sample video named `file_example_MP4_640_3MG.mp4`. The downloaded practice video must **not** be submitted as the student's original video. Before final submission:

1. Record your own unedited video of approximately **15–30 seconds**, showing a moving person or object and enough background detail.
2. Save it as `input/my_recorded_video.mp4`.
3. In notebook cells for video inspection, frame extraction, MOG2 and Lucas–Kanade, change the video path to:

   ```python
   video_path = INPUT_DIR / "my_recorded_video.mp4"
   ```

4. Run Task 4 again and replace the corresponding output images and observations in the report.

## Report and submission links

- Technical report: `docs/CCA3_Computer_Vision_Report.docx`
- GitHub repository URL: **Add the repository URL after creating the GitHub repository.**
- Google Drive submission folder: **Add link after uploading the final submission package.**
- Project explanation video (5–8 minutes): **Add link after recording and uploading.**

Fill in your student name, PRN/roll number, submission date, GitHub URL and Drive/video links in the report before final submission.

## Notes

- The `outputs/` folder contains selected visual outputs. Re-run the notebook to regenerate the complete set of outputs and CSV comparison files.
- Large raw videos are intentionally not included in this GitHub package. Add the required self-recorded video to the final submission folder on Google Drive as well.
- Do not upload passwords, API keys, private credentials or unrelated personal files.


## Notebook output files

For a smaller repository upload, the notebook is saved with code and markdown cells but without embedded execution outputs. Selected output figures are stored separately in `outputs/`. Run the notebook to regenerate the cell outputs and results.
